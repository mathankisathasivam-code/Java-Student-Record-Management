# Student Management System

A Java console application for maintaining student records. This is a portfolio learning project that demonstrates object-oriented programming, collections, input validation, and file handling.

## Features
- Add a student with a unique ID
- View all student records
- Search by student ID
- Update student details
- Delete a student record
- Calculate a grade from marks
- Dashboard summary (count, average, highest and lowest marks)
- Automatically save records to `data/students.txt`
- Load saved records when the program starts
- Validate IDs, marks and email input

## Technology
- Java (JDK 17 or later)
- Java standard library only; no external dependencies

## Project structure
```text
Student-Management-System/
├── src/
│   ├── Main.java
│   ├── Student.java
│   └── StudentManager.java
├── data/
│   └── .gitkeep
├── docs/
│   └── PROJECT-PLAN.md
├── README.md
├── .gitignore
└── LICENSE
```

## Run on Windows
First install a JDK (not only a Java browser runtime). Then open Command Prompt in the project folder and check:

```cmd
java -version
javac -version
```

Compile the source files:

```cmd
javac -d out src\Main.java src\Student.java src\StudentManager.java
```

Run the application:

```cmd
java -cp out Main
```

If `java` or `javac` is “not recognized”, the JDK is not installed or its `bin` folder is not on PATH. See the setup guide below.

## Run on macOS / Linux
```bash
javac -d out src/Main.java src/Student.java src/StudentManager.java
java -cp out Main
```

## Data storage
Student records are stored locally in `data/students.txt`. The file is created automatically after the first successful add/update/delete. Keep this file if you want to retain your local sample records. Avoid committing real personal student information to a public repository; use dummy data only.

## Learning roadmap
1. Understand classes, objects, constructors and encapsulation.
2. Understand `ArrayList` and searching by ID.
3. Understand input validation and menu-driven programs.
4. Understand reading/writing text files.
5. Next version: connect MySQL using JDBC.
6. Later version: build a web UI with Spring Boot and a frontend.

## Author
Add your name and GitHub profile here before publishing.
