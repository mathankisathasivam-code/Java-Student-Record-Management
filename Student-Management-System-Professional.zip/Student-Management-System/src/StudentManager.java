import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class StudentManager {
    private final List<Student> students = new ArrayList<>();
    private final Path dataFile = Paths.get("data", "students.txt");

    public StudentManager() {
        loadFromFile();
    }

    public List<Student> getStudents() {
        return new ArrayList<>(students);
    }

    public Student findById(int id) {
        for (Student student : students) {
            if (student.getId() == id) return student;
        }
        return null;
    }

    public boolean add(Student student) {
        if (findById(student.getId()) != null) return false;
        students.add(student);
        saveToFile();
        return true;
    }

    public boolean update(int id, String name, String department, String email, int marks) {
        Student student = findById(id);
        if (student == null) return false;
        student.updateDetails(name, department, email, marks);
        saveToFile();
        return true;
    }

    public boolean delete(int id) {
        Student student = findById(id);
        if (student == null) return false;
        students.remove(student);
        saveToFile();
        return true;
    }

    public double getAverageMarks() {
        if (students.isEmpty()) return 0;
        int total = 0;
        for (Student student : students) total += student.getMarks();
        return (double) total / students.size();
    }

    private void loadFromFile() {
        try {
            Files.createDirectories(dataFile.getParent());
            if (!Files.exists(dataFile)) return;
            for (String line : Files.readAllLines(dataFile, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                Student student = Student.fromDataLine(line);
                if (student != null && findById(student.getId()) == null) {
                    students.add(student);
                }
            }
        } catch (IOException ex) {
            System.out.println("Note: Could not load saved records: " + ex.getMessage());
        }
    }

    private void saveToFile() {
        try {
            Files.createDirectories(dataFile.getParent());
            List<String> lines = new ArrayList<>();
            for (Student student : students) lines.add(student.toDataLine());
            Files.write(dataFile, lines, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.out.println("Warning: Could not save records: " + ex.getMessage());
        }
    }
}
