public class Student {
    private final int id;
    private String name;
    private String department;
    private String email;
    private int marks;

    public Student(int id, String name, String department, String email, int marks) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.email = email;
        this.marks = marks;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public String getEmail() { return email; }
    public int getMarks() { return marks; }

    public void updateDetails(String name, String department, String email, int marks) {
        this.name = name;
        this.department = department;
        this.email = email;
        this.marks = marks;
    }

    public String getGrade() {
        if (marks >= 90) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        if (marks >= 50) return "D";
        return "F";
    }

    // Pipe characters are not accepted in input, so this format stays easy to read.
    public String toDataLine() {
        return id + "|" + name + "|" + department + "|" + email + "|" + marks;
    }

    public static Student fromDataLine(String line) {
        String[] parts = line.split("\\\\|", -1);
        if (parts.length != 5) return null;
        try {
            return new Student(
                Integer.parseInt(parts[0]),
                parts[1], parts[2], parts[3],
                Integer.parseInt(parts[4])
            );
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    public void display() {
        System.out.printf("%-6d %-20s %-16s %-28s %-7d %-4s%n",
            id, name, department, email, marks, getGrade());
    }
}
