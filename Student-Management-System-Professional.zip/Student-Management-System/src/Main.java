import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner input = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager();

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println("          STUDENT MANAGEMENT SYSTEM");
        System.out.println("==============================================");
        System.out.println("Your records are saved automatically.");

        boolean running = true;
        while (running) {
            showMenu();
            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> addStudent();
                case 2 -> viewStudents();
                case 3 -> searchStudent();
                case 4 -> updateStudent();
                case 5 -> deleteStudent();
                case 6 -> showDashboard();
                case 0 -> {
                    running = false;
                    System.out.println("Thank you. Your records have been saved.");
                }
                default -> System.out.println("Please choose a number from 0 to 6.");
            }
        }
        input.close();
    }

    private static void showMenu() {
        System.out.println("\\n--------------- MAIN MENU ----------------");
        System.out.println("1. Add student");
        System.out.println("2. View all students");
        System.out.println("3. Search student by ID");
        System.out.println("4. Update student");
        System.out.println("5. Delete student");
        System.out.println("6. Dashboard summary");
        System.out.println("0. Exit");
        System.out.println("-------------------------------------------");
    }

    private static void addStudent() {
        System.out.println("\\n--- ADD STUDENT ---");
        int id = readPositiveInt("Student ID: ");
        if (manager.findById(id) != null) {
            System.out.println("That ID is already in use.");
            return;
        }
        String name = readText("Full name: ");
        String department = readText("Department: ");
        String email = readEmail();
        int marks = readMarks();

        if (manager.add(new Student(id, name, department, email, marks))) {
            System.out.println("Student added and saved successfully.");
        }
    }

    private static void viewStudents() {
        List<Student> students = manager.getStudents();
        if (students.isEmpty()) {
            System.out.println("No student records found. Add a student first.");
            return;
        }
        printTableHeader();
        for (Student student : students) student.display();
        System.out.println("\\nTotal records: " + students.size());
    }

    private static void searchStudent() {
        int id = readPositiveInt("Enter student ID: ");
        Student student = manager.findById(id);
        if (student == null) {
            System.out.println("No student found with ID " + id + ".");
        } else {
            printTableHeader();
            student.display();
        }
    }

    private static void updateStudent() {
        int id = readPositiveInt("Enter the ID to update: ");
        if (manager.findById(id) == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("Enter the new details:");
        String name = readText("Full name: ");
        String department = readText("Department: ");
        String email = readEmail();
        int marks = readMarks();
        manager.update(id, name, department, email, marks);
        System.out.println("Student updated and saved successfully.");
    }

    private static void deleteStudent() {
        int id = readPositiveInt("Enter the ID to delete: ");
        if (manager.delete(id)) {
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void showDashboard() {
        List<Student> students = manager.getStudents();
        System.out.println("\\n------------- DASHBOARD SUMMARY -------------");
        System.out.println("Total students : " + students.size());
        System.out.printf("Average marks  : %.2f%n", manager.getAverageMarks());
        if (!students.isEmpty()) {
            int highest = 0;
            int lowest = 100;
            for (Student student : students) {
                highest = Math.max(highest, student.getMarks());
                lowest = Math.min(lowest, student.getMarks());
            }
            System.out.println("Highest marks  : " + highest);
            System.out.println("Lowest marks   : " + lowest);
        }
        System.out.println("---------------------------------------------");
    }

    private static void printTableHeader() {
        System.out.printf("%-6s %-20s %-16s %-28s %-7s %-4s%n",
            "ID", "NAME", "DEPARTMENT", "EMAIL", "MARKS", "GRADE");
        System.out.println("------------------------------------------------------------------------------------------");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(input.nextLine().trim());
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) return value;
            System.out.println("ID must be greater than zero.");
        }
    }

    private static int readMarks() {
        while (true) {
            int marks = readInt("Marks (0-100): ");
            if (marks >= 0 && marks <= 100) return marks;
            System.out.println("Marks must be between 0 and 100.");
        }
    }

    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = input.nextLine().trim();
            if (!value.isEmpty() && !value.contains("|")) return value;
            System.out.println("Please enter a value. The | character is not allowed.");
        }
    }

    private static String readEmail() {
        while (true) {
            String email = readText("Email: ");
            if (email.matches("^[^\\\\s@]+@[^\\\\s@]+\\\\.[^\\\\s@]+$")) return email;
            System.out.println("Please enter a valid email address.");
        }
    }
}
