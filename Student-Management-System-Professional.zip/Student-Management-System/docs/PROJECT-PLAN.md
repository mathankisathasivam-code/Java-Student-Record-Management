# Project Plan

## Version 1 – Java console application
- [x] Add student
- [x] List all students
- [x] Search by ID
- [x] Update details
- [x] Delete student
- [x] Grade calculation
- [x] Dashboard summary
- [x] Save and load records from a local text file
- [x] Basic input validation

## Version 2 – Database
- [ ] Design a MySQL `students` table
- [ ] Connect Java using JDBC
- [ ] Replace text-file storage with database operations

## Version 3 – Web application
- [ ] Build REST APIs using Spring Boot
- [ ] Add a frontend
- [ ] Add login and role-based access
- [ ] Add tests and deployment

## Demo checklist
1. Add two students using fictional details.
2. View all records.
3. Search for one ID.
4. Update that student's details.
5. View dashboard summary.
6. Exit and run the program again to confirm records load.
7. Delete a sample student.
